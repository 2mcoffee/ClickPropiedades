
--
-- Dumping data for table `tipo_inmuebles`
--

INSERT INTO `tipo_inmuebles` (`id_tipo_inmueble`, `descripcion`, `orden`) VALUES
(1, 'DEPARTAMENTOS', 1),
(2, 'CASAS', 3),
(3, 'PH', 2),
(4, 'QUINTAS', 9),
(5, 'LOTES', 10),
(6, 'CAMPOS', 11),
(7, 'CHACRAS', 12),
(8, 'GALPONES', 13),
(9, 'LOCALES', 14),
(10, 'OFICINAS', 15),
(11, 'CONSULTORIOS', 16),
(12, 'CHALETS', 4),
(13, 'DUPLEX', 5),
(14, 'TRIPLEX', 6),
(15, 'MULTIFAMILIAR', 7),
(16, 'EMPRENDIMIENTOS', 8),
(17, 'FONDO DE COMERCIO', 17),
(18, 'COCHERAS', 18);
