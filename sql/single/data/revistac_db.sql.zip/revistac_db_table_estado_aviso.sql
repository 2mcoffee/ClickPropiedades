
--
-- Dumping data for table `estado_aviso`
--

INSERT INTO `estado_aviso` (`id_estadoAviso`, `descripcion`) VALUES
(1, 'Cerrado'),
(2, 'Alquiler'),
(3, 'Reservado');
