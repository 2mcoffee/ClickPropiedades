
--
-- Dumping data for table `tipo_plan_inmobiliarias`
--

INSERT INTO `tipo_plan_inmobiliarias` (`id_tipo_plan`, `descripcion`, `cantidad_inmueble`) VALUES
(1, 'Base', 5),
(2, 'Amigo', 10),
(3, 'Cliente', 15),
(4, 'Vip', 20),
(5, 'Ilimitado', 2147483647);
