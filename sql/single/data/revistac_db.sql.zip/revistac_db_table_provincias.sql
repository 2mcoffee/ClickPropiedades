
--
-- Dumping data for table `provincias`
--

INSERT INTO `provincias` (`id_provincia`, `descripcion`) VALUES
(1, 'BUENOS AIRES'),
(2, 'CAPITAL FEDERAL'),
(3, 'CATAMARCA'),
(4, 'CHACO'),
(5, 'CHUBUT'),
(6, 'CORDOBA'),
(7, 'CORRIENTES'),
(8, 'ENTRE RIOS'),
(9, 'FORMOSA'),
(10, 'JUJUY'),
(11, 'LA PAMPA'),
(12, 'LA RIOJA'),
(13, 'MENDOZA'),
(14, 'MISIONES'),
(15, 'NEUQUEN'),
(16, 'RIO NEGRO'),
(17, 'SALTA'),
(18, 'SAN JUAN'),
(19, 'SAN LUIS'),
(20, 'SANTA CRUZ'),
(21, 'SANTA FE'),
(22, 'SANTIAGO DEL ESTERO'),
(23, 'TIERRA DEL FUEGO'),
(24, 'TUCUMAN');
