
--
-- Dumping data for table `destacados`
--

INSERT INTO `destacados` (`id_destacado`, `id_aviso`, `orden`) VALUES
(6, 72, NULL),
(5, 71, NULL),
(3, 0, NULL),
(4, 17, NULL),
(7, 73, NULL),
(8, 55, NULL),
(9, 62, NULL),
(10, 70, NULL),
(11, 66, NULL),
(12, 28, NULL),
(13, 17, NULL),
(14, 420, NULL),
(15, 69, NULL),
(32, 903, NULL),
(33, 920, NULL),
(20, 354, NULL),
(19, 352, NULL),
(22, 289, NULL),
(23, 0, NULL),
(24, 0, NULL),
(25, 287, NULL),
(27, 783, NULL),
(28, 313, NULL),
(29, 746, NULL),
(30, 919, NULL),
(31, 918, NULL),
(34, 987, NULL),
(35, 893, NULL),
(36, 1174, NULL);
