
--
-- Dumping data for table `tipo_operaciones`
--

INSERT INTO `tipo_operaciones` (`id_tipo_operacion`, `descripcion`) VALUES
(1, 'VENTA'),
(2, 'ALQUILER'),
(3, 'TEMPORAL');
