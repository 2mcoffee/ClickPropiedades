
--
-- Dumping data for table `tipo_monedas`
--

INSERT INTO `tipo_monedas` (`id_tipo_moneda`, `descripcion`) VALUES
(1, '$'),
(2, 'USD'),
(3, 'EUR');
