
-- --------------------------------------------------------

--
-- Table structure for table `estado_aviso`
--

CREATE TABLE `estado_aviso` (
  `id_estadoAviso` int(11) NOT NULL DEFAULT '0',
  `descripcion` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
