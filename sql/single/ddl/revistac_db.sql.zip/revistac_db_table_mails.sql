
-- --------------------------------------------------------

--
-- Table structure for table `mails`
--

CREATE TABLE `mails` (
  `id_mail` bigint(20) NOT NULL,
  `mail` varchar(50) DEFAULT NULL,
  `id_inmobiliaria` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
