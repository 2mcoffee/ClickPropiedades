
-- --------------------------------------------------------

--
-- Table structure for table `tipo_inmuebles`
--

CREATE TABLE `tipo_inmuebles` (
  `id_tipo_inmueble` int(11) NOT NULL,
  `descripcion` varchar(30) DEFAULT NULL,
  `orden` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
