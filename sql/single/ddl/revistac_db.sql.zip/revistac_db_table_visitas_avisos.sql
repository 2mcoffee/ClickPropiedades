
-- --------------------------------------------------------

--
-- Table structure for table `visitas_avisos`
--

CREATE TABLE `visitas_avisos` (
  `id_aviso` bigint(20) DEFAULT NULL,
  `fecha_visita` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
