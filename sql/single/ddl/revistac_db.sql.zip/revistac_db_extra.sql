
--
-- Indexes for dumped tables
--

--
-- Indexes for table `avisos`
--
ALTER TABLE `avisos`
  ADD PRIMARY KEY (`id_aviso`),
  ADD KEY `id_inmobiliaria` (`id_inmobiliaria`),
  ADD KEY `id_caracteristica` (`id_caracteristica`),
  ADD KEY `id_dato_basico` (`id_dato_basico`),
  ADD KEY `id_localidad` (`id_localidad`),
  ADD KEY `id_domicilio` (`id_domicilio`),
  ADD KEY `id_estadoAviso` (`id_estadoAviso`);

--
-- Indexes for table `caracteristicas`
--
ALTER TABLE `caracteristicas`
  ADD PRIMARY KEY (`id_caracteristica`);

--
-- Indexes for table `datos_basicos`
--
ALTER TABLE `datos_basicos`
  ADD PRIMARY KEY (`id_dato_basico`),
  ADD KEY `id_tipo_inmueble` (`id_tipo_inmueble`),
  ADD KEY `id_tipo_operacion` (`id_tipo_operacion`),
  ADD KEY `id_tipo_moneda` (`id_tipo_moneda`);

--
-- Indexes for table `destacados`
--
ALTER TABLE `destacados`
  ADD PRIMARY KEY (`id_destacado`),
  ADD KEY `id_aviso` (`id_aviso`);

--
-- Indexes for table `domicilios`
--
ALTER TABLE `domicilios`
  ADD PRIMARY KEY (`id_domicilio`);

--
-- Indexes for table `estado_aviso`
--
ALTER TABLE `estado_aviso`
  ADD PRIMARY KEY (`id_estadoAviso`);

--
-- Indexes for table `fotos`
--
ALTER TABLE `fotos`
  ADD PRIMARY KEY (`id_foto`),
  ADD KEY `id_aviso` (`id_aviso`);

--
-- Indexes for table `inmobiliarias`
--
ALTER TABLE `inmobiliarias`
  ADD PRIMARY KEY (`id_inmobiliaria`),
  ADD KEY `id_tipo_plan` (`id_tipo_plan`),
  ADD KEY `id_domicilio` (`id_domicilio`),
  ADD KEY `id_localidad` (`id_localidad`);

--
-- Indexes for table `localidades`
--
ALTER TABLE `localidades`
  ADD PRIMARY KEY (`id_localidad`),
  ADD KEY `id_partido` (`id_partido`);

--
-- Indexes for table `mails`
--
ALTER TABLE `mails`
  ADD PRIMARY KEY (`id_mail`),
  ADD KEY `id_inmobiliaria` (`id_inmobiliaria`);

--
-- Indexes for table `partidos`
--
ALTER TABLE `partidos`
  ADD PRIMARY KEY (`id_partido`),
  ADD KEY `id_provincia` (`id_provincia`);

--
-- Indexes for table `provincias`
--
ALTER TABLE `provincias`
  ADD PRIMARY KEY (`id_provincia`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indexes for table `telefonos`
--
ALTER TABLE `telefonos`
  ADD PRIMARY KEY (`id_telefono`),
  ADD KEY `id_inmobiliaria` (`id_inmobiliaria`);

--
-- Indexes for table `tipo_inmuebles`
--
ALTER TABLE `tipo_inmuebles`
  ADD PRIMARY KEY (`id_tipo_inmueble`);

--
-- Indexes for table `tipo_monedas`
--
ALTER TABLE `tipo_monedas`
  ADD PRIMARY KEY (`id_tipo_moneda`);

--
-- Indexes for table `tipo_operaciones`
--
ALTER TABLE `tipo_operaciones`
  ADD PRIMARY KEY (`id_tipo_operacion`);

--
-- Indexes for table `tipo_plan_inmobiliarias`
--
ALTER TABLE `tipo_plan_inmobiliarias`
  ADD PRIMARY KEY (`id_tipo_plan`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `id_rol` (`id_rol`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `avisos`
--
ALTER TABLE `avisos`
  MODIFY `id_aviso` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1503;
--
-- AUTO_INCREMENT for table `caracteristicas`
--
ALTER TABLE `caracteristicas`
  MODIFY `id_caracteristica` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1503;
--
-- AUTO_INCREMENT for table `datos_basicos`
--
ALTER TABLE `datos_basicos`
  MODIFY `id_dato_basico` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1503;
--
-- AUTO_INCREMENT for table `domicilios`
--
ALTER TABLE `domicilios`
  MODIFY `id_domicilio` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1950;
--
-- AUTO_INCREMENT for table `fotos`
--
ALTER TABLE `fotos`
  MODIFY `id_foto` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4603;
--
-- AUTO_INCREMENT for table `inmobiliarias`
--
ALTER TABLE `inmobiliarias`
  MODIFY `id_inmobiliaria` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=448;
--
-- AUTO_INCREMENT for table `mails`
--
ALTER TABLE `mails`
  MODIFY `id_mail` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=448;
--
-- AUTO_INCREMENT for table `telefonos`
--
ALTER TABLE `telefonos`
  MODIFY `id_telefono` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=448;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=449;