
-- --------------------------------------------------------

--
-- Table structure for table `telefonos`
--

CREATE TABLE `telefonos` (
  `id_telefono` bigint(20) NOT NULL,
  `numero` varchar(20) DEFAULT NULL,
  `region` varchar(10) DEFAULT NULL,
  `movil` varchar(15) DEFAULT NULL,
  `id_inmobiliaria` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
