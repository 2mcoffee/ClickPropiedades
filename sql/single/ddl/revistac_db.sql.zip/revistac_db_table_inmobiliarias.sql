
-- --------------------------------------------------------

--
-- Table structure for table `inmobiliarias`
--

CREATE TABLE `inmobiliarias` (
  `id_inmobiliaria` bigint(20) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `cuit` varchar(13) DEFAULT NULL,
  `url_log` varchar(200) DEFAULT NULL,
  `habilitada` bit(1) DEFAULT NULL,
  `id_tipo_plan` int(11) DEFAULT NULL,
  `id_domicilio` bigint(20) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `id_usuario` bigint(20) DEFAULT NULL,
  `fecha_alta_plan` datetime DEFAULT NULL,
  `URL` varchar(50) DEFAULT NULL,
  `contacto` varchar(50) DEFAULT NULL,
  `id_localidad` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
