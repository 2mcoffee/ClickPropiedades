
-- --------------------------------------------------------

--
-- Table structure for table `datos_basicos`
--

CREATE TABLE `datos_basicos` (
  `id_dato_basico` bigint(20) NOT NULL,
  `id_tipo_inmueble` int(11) DEFAULT NULL,
  `id_tipo_operacion` int(11) DEFAULT NULL,
  `id_tipo_moneda` int(11) DEFAULT NULL,
  `precio` decimal(10,0) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
