
-- --------------------------------------------------------

--
-- Table structure for table `caracteristicas`
--

CREATE TABLE `caracteristicas` (
  `id_caracteristica` bigint(20) NOT NULL,
  `can_ambientes` int(11) DEFAULT NULL,
  `can_dormitorios` int(11) DEFAULT NULL,
  `antiguedad` int(11) DEFAULT NULL,
  `disposicion` varchar(30) DEFAULT NULL,
  `profesional` char(2) DEFAULT NULL,
  `terraza` varchar(10) DEFAULT NULL,
  `luminosidad` varchar(10) DEFAULT NULL,
  `seguridad` varchar(10) DEFAULT NULL,
  `sup_total` int(11) DEFAULT NULL,
  `sup_cubierta` int(11) DEFAULT NULL,
  `banos` varchar(10) DEFAULT NULL,
  `toilette` varchar(10) DEFAULT NULL,
  `garage` varchar(10) DEFAULT NULL,
  `balcon` varchar(10) DEFAULT NULL,
  `patio` varchar(10) DEFAULT NULL,
  `jardin` varchar(10) DEFAULT NULL,
  `pileta` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
