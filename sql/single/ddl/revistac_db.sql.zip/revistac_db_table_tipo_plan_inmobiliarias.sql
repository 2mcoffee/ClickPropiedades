
-- --------------------------------------------------------

--
-- Table structure for table `tipo_plan_inmobiliarias`
--

CREATE TABLE `tipo_plan_inmobiliarias` (
  `id_tipo_plan` int(11) NOT NULL,
  `descripcion` varchar(30) DEFAULT NULL,
  `cantidad_inmueble` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
