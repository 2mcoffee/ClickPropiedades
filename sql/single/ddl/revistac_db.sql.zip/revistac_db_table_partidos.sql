
-- --------------------------------------------------------

--
-- Table structure for table `partidos`
--

CREATE TABLE `partidos` (
  `id_partido` int(11) NOT NULL DEFAULT '0',
  `descripcion` varchar(50) DEFAULT NULL,
  `id_provincia` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
