
-- --------------------------------------------------------

--
-- Table structure for table `tipo_monedas`
--

CREATE TABLE `tipo_monedas` (
  `id_tipo_moneda` int(11) NOT NULL,
  `descripcion` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
