
-- --------------------------------------------------------

--
-- Table structure for table `tipo_operaciones`
--

CREATE TABLE `tipo_operaciones` (
  `id_tipo_operacion` int(11) NOT NULL,
  `descripcion` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
