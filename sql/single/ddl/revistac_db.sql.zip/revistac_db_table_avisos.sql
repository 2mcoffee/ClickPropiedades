
-- --------------------------------------------------------

--
-- Table structure for table `avisos`
--

CREATE TABLE `avisos` (
  `id_aviso` bigint(20) NOT NULL,
  `id_inmobiliaria` bigint(20) NOT NULL,
  `id_caracteristica` bigint(20) DEFAULT NULL,
  `id_dato_basico` bigint(20) DEFAULT NULL,
  `codigoficha` varchar(30) DEFAULT NULL,
  `id_localidad` int(11) DEFAULT NULL,
  `id_domicilio` bigint(20) DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_estadoAviso` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
