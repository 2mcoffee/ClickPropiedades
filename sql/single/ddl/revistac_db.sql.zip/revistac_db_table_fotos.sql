
-- --------------------------------------------------------

--
-- Table structure for table `fotos`
--

CREATE TABLE `fotos` (
  `id_foto` bigint(20) NOT NULL,
  `url` varchar(100) DEFAULT NULL,
  `orden` int(11) DEFAULT NULL,
  `id_aviso` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
