
-- --------------------------------------------------------

--
-- Table structure for table `domicilios`
--

CREATE TABLE `domicilios` (
  `id_domicilio` bigint(20) NOT NULL,
  `calle` varchar(50) DEFAULT NULL,
  `altura` int(11) DEFAULT NULL,
  `piso` varchar(10) DEFAULT NULL,
  `depto` varchar(9) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
